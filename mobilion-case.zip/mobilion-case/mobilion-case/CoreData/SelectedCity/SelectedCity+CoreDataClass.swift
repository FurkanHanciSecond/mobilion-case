//
//  SelectedCity+CoreDataClass.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/12/22.
//
//

import Foundation
import CoreData

@objc(SelectedCity)
public class SelectedCity: NSManagedObject {

}
