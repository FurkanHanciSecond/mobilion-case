//
//  SelectedCity+CoreDataProperties.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/12/22.
//
//

import Foundation
import CoreData


extension SelectedCity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<SelectedCity> {
        return NSFetchRequest<SelectedCity>(entityName: "SelectedCity")
    }

    @NSManaged public var name: String?
    @NSManaged public var lat: Double
    @NSManaged public var lon: Double

}

extension SelectedCity : Identifiable {

}
