//
//  CityData+CoreDataProperties.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/9/22.
//
//

import Foundation
import CoreData


extension CityData {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CityData> {
        return NSFetchRequest<CityData>(entityName: "CityData")
    }

    @NSManaged public var latitude: Double
    @NSManaged public var longitude: Double
    @NSManaged public var name: String?
    @NSManaged public var date: String?
    @NSManaged public var image: String?
    @NSManaged public var celcius: String?

}

extension CityData : Identifiable {

}
