//
//  CityData+CoreDataClass.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/9/22.
//
//

import Foundation
import CoreData

@objc(CityData)
public class CityData: NSManagedObject {

}
