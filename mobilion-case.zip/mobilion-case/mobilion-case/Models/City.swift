//
//  City.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/6/22.
//

import Foundation

struct City {
    let category : String?
    let cityArray : [CityModel]
}


struct CityModel : Codable {
    let coord : Coordinate?
    let country : String?
    let id : Int?
    let name : String?
    let state : String?
}

struct Coordinate : Codable {
    let lat : Double?
    let lon : Double?
}

// MARK: - All Cities Dummy

var aCities = City(category: "A", cityArray: [CityModel(coord: Coordinate(lat: 36.985001, lon: 35.28809), country: "TR", id: 325361, name: "Adana", state: "") , CityModel(coord: Coordinate(lat: 37.75, lon: 38.25), country: "TR", id: 325329, name: "Adıyaman", state: "") , CityModel(coord: Coordinate(lat: 38.75, lon: 30.66667), country: "TR", id: 325302, name: "AfyonKarahisar", state: "") , CityModel(coord: Coordinate(lat: 39.71944, lon: 43.051392), country: "TR", id: 309647, name: "Ağrı", state: "") , CityModel(coord: Coordinate(lat: 40.666672, lon: 35.833328), country: "TR", id: 752014, name: "Amasya", state: "") , CityModel(coord: Coordinate(lat: 39.916672, lon: 32.833328), country: "TR", id: 323784, name: "Ankara", state: "")])

var bCities = City(category: "B", cityArray: [CityModel(coord: Coordinate(lat: 40.666672, lon: 31.58333), country: "TR", id: 750510, name: "Bolu", state: "") , CityModel(coord: Coordinate(lat: 37.5, lon: 30), country: "TR", id: 320390, name: "Burdur", state: "") ])

var dCities = City(category: "D", cityArray: [CityModel(coord: Coordinate(lat: 37.84016, lon: 29.06982), country: "TR", id: 317106, name: "Denizli", state: "") , CityModel(coord: Coordinate(lat: 37.961521, lon: 40.23193), country: "TR", id: 316540, name: "Diyarbakır", state: "")])

var eCities = City(category: "E", cityArray: [CityModel(coord: Coordinate(lat: 41.25, lon: 26.66667), country: "TR", id: 747711, name: "Edirne", state: "") , ])

var iCities = City(category: "I", cityArray: [CityModel(coord: Coordinate(lat: 41.03508, lon: 28.983311), country: "TR", id: 745042, name: "İstanbul", state: "") , CityModel(coord: Coordinate(lat: 38.462189, lon: 27.092291), country: "TR", id: 311044, name: "İzmir", state: "")])

var mCities = City(category: "M", cityArray: [CityModel(coord: Coordinate(lat: 38.5, lon: 38), country: "TR", id: 304919, name: "Malatya", state: "") , CityModel(coord: Coordinate(lat: 38.833328, lon: 28.16667), country: "TR", id: 304825, name: "Manisa", state: "") , ])

var rCities = City(category: "R", cityArray: [CityModel(coord: Coordinate(lat: 40.90443, lon: 40.89489), country: "TR", id: 740481, name: "Rize", state: "")])

var hCities = City(category: "H", cityArray: [CityModel(coord: Coordinate(lat: 36.5, lon: 36.25), country: "TR", id: 312394, name: "Hatay", state: "")])

var kCities = City(category: "K", cityArray: [CityModel(coord: Coordinate(lat: 40.416672, lon: 43.083328), country: "TR", id: 743942, name: "Kars", state: "") , CityModel(coord: Coordinate(lat: 41.5, lon: 33.666672), country: "TR", id: 743881, name: "Kastamonu", state: "") , CityModel(coord: Coordinate(lat: 40.916672, lon: 29.91667), country: "TR", id: 742865, name: "Kocaeli", state: "")])

var tCities = City(category: "T", cityArray: [CityModel(coord: Coordinate(lat: 40.416672, lon: 36.583328), country: "TR", id: 738742, name: "Tokat", state: "")])

var nCities = City(category: "N", cityArray: [CityModel(coord: Coordinate(lat: 38.916672, lon: 34.666672), country: "TR", id: 303830, name: "Nevşehir", state: "")])

var cityArray = [aCities , bCities , dCities , eCities , iCities , mCities , rCities , hCities , kCities , tCities , nCities]

// MARK: - City Dummy
//var adana = City(coord: Coordinate(lat: 36.985001, lon: 35.28809), country: "TR", id: 325361, name: "Adana", state: "")
//var adiyaman = City(coord: Coordinate(lat: 37.75, lon: 38.25), country: "TR", id: 325329, name: "Adıyaman", state: "")
//var afyonkarahisar = City(coord: Coordinate(lat: 38.75, lon: 30.66667), country: "TR", id: 325302, name: "AfyonKarahisar", state: "")
//var agri = City(coord: Coordinate(lat: 39.71944, lon: 43.051392), country: "TR", id: 309647, name: "Ağrı", state: "")
//var amasya = City(coord: Coordinate(lat: 40.666672, lon: 35.833328), country: "TR", id: 752014, name: "Amasya", state: "")
//var ankara = City(coord: Coordinate(lat: 39.916672, lon: 32.833328), country: "TR", id: 323784, name: "Ankara", state: "")
//var istanbul = City(coord: Coordinate(lat: 41.03508, lon: 28.983311), country: "TR", id: 745042, name: "İstanbul", state: "")
//var izmir = City(coord: Coordinate(lat: 38.462189, lon: 27.092291), country: "TR", id: 311044, name: "İzmir", state: "")
//var malatya = City(coord: Coordinate(lat: 38.5, lon: 38), country: "TR", id: 304919, name: "Malatya", state: "")
//var manisa = City(coord: Coordinate(lat: 38.833328, lon: 28.16667), country: "TR", id: 304825, name: "Manisa", state: "")
//var rize = City(coord: Coordinate(lat: 40.90443, lon: 40.89489), country: "TR", id: 740481, name: "Rize", state: "")
//var tokat = City(coord: Coordinate(lat: 40.416672, lon: 36.583328), country: "TR", id: 738742, name: "Tokat", state: "")
//var bolu = City(coord: Coordinate(lat: 40.666672, lon: 31.58333), country: "TR", id: 750510, name: "Bolu", state: "")
//var burdur = City(coord: Coordinate(lat: 37.5, lon: 30), country: "TR", id: 320390, name: "Burdur", state: "")
//var denizli = City(coord: Coordinate(lat: 37.84016, lon: 29.06982), country: "TR", id: 317106, name: "Denizli", state: "")
//var edirne = City(coord: Coordinate(lat: 41.25, lon: 26.66667), country: "TR", id: 747711, name: "Edirne", state: "")
//var hatay = City(coord: Coordinate(lat: 36.5, lon: 36.25), country: "TR", id: 312394, name: "Hatay", state: "")
//var kars = City(coord: Coordinate(lat: 40.416672, lon: 43.083328), country: "TR", id: 743942, name: "Kars", state: "")
//var kastamonu = City(coord: Coordinate(lat: 41.5, lon: 33.666672), country: "TR", id: 743881, name: "Kastamonu", state: "")
//var nevsehir = City(coord: Coordinate(lat: 38.916672, lon: 34.666672), country: "TR", id: 303830, name: "Nevşehir", state: "")

