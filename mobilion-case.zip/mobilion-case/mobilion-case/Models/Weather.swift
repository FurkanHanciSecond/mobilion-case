//
//  Weather.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/5/22.
//

import Foundation

struct Weather: Decodable {
    let id: Int?
    let main: String?
    let description: String?
    let icon: String?
}
