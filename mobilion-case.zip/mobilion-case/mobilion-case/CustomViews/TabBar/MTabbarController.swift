//
//  MTabbarController.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/5/22.
//

import UIKit

class MTabbarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        configureTabBar()
        setTabs()
    }
    
    private func configureTabBar() {
        tabBar.barTintColor = Constants.Style.Color.tabBarTintColor
        tabBar.tintColor = Constants.Style.Color.tabTintColor
    }
    
    //TODO: Edit ViewControllers
    private func setTabs() {
        viewControllers = [
         homeVC(),
         cityVC()
        
        ]
    }
    
    private func homeVC() -> UINavigationController {
        let homeViewController = HomeViewController()
        let homeTabBarItem = UITabBarItem(title: Constants.Texts.Bar.home, image: Constants.Style.Image.homeTabImage, selectedImage: Constants.Style.Image.homeTabImage)
        
        homeViewController.tabBarItem = homeTabBarItem
        return UINavigationController(rootViewController: homeViewController)
    }
    
    private func cityVC() -> UINavigationController {
        let cityViewController = CityViewController()
        let cityTabBarItem = UITabBarItem(title: Constants.Texts.Bar.cities, image: Constants.Style.Image.cityTabImage, selectedImage: Constants.Style.Image.cityTabImage)
        
        cityViewController.tabBarItem = cityTabBarItem
        
        return UINavigationController(rootViewController: cityViewController)
    }

}
