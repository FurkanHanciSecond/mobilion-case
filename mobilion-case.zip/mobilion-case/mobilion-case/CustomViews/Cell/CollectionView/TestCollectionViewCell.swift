//
//  TestCollectionViewCell.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/11/22.
//

import UIKit

class TestCollectionViewCell: UICollectionViewCell {
    static let Id = String(describing: TestCollectionViewCell.self)
    
    private lazy var testLabel = WeatherLabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .clear
        configure()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func set(data : CityModel) {
        testLabel.text = data.name
    }
    
    private func configure() {
        contentView.addSubview(testLabel)
        NSLayoutConstraint.activate([
            testLabel.leadingAnchor.constraint(equalTo: leadingAnchor , constant: 20),
            testLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
}
