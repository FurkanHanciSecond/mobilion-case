//
//  AddCityCell.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/6/22.
//

protocol AddCityCellDelegate : AnyObject {
    func saveData()
}

import UIKit
import SnapKit
class AddCityCell: UITableViewCell {
    
    private lazy var cityNameLabel = WeatherLabel(fontSize: 14, fontWeight: .medium, textColor: .black)
    private lazy var addButton = WeatherButton()
    weak var delegate : AddCityCellDelegate?
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: Constants.cellID)
        setupCell()
    }
    
        
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private func setupCell() {
        selectionStyle = .none
        backgroundColor = .clear
        setupUI()
        configureButton()
    }
    
    private func configureButton() {
        addButton.set(backgroundColor: .clear, title: "Ekle")
        addButton.addTarget(self, action: #selector(addButtonHandle(_:)), for: .touchUpInside)
    }
    
    @objc private func addButtonHandle(_ sender : UIButton) {
        delegate?.saveData()
    }
    
    private func setupUI() {
        let padding : CGFloat = 15
        let horizontalPadding: CGFloat = 10
        let verticalPadding: CGFloat = 3
        contentView.addSubviews(cityNameLabel , addButton)
        
        
        cityNameLabel.snp.makeConstraints { make in
            make.leading.equalTo(contentView).offset(padding)
            make.bottom.equalTo(contentView)
        }
        
        addButton.snp.makeConstraints { make in
            make.trailing.equalTo(-horizontalPadding)
            make.bottom.equalTo(verticalPadding)
        }
    }
    
    public func setCell(cityData : CityModel) {
        cityNameLabel.text = cityData.name
    }
}
