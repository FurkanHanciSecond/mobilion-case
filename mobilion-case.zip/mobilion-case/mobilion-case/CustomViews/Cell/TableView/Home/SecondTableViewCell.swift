//
//  SecondTableViewCell.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/11/22.
//

import UIKit

class SecondTableViewCell: UITableViewCell {
    
    private lazy var detailView = WeatherDetailView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: Constants.secondCellID)
        setupCell()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupCell() {
        selectionStyle = .none
        contentView.addSubview(detailView)
        detailView.translatesAutoresizingMaskIntoConstraints = false
        detailView.sizeToFit()
        
        NSLayoutConstraint.activate([
        
           detailView.leadingAnchor.constraint(equalTo: leadingAnchor),
            detailView.topAnchor.constraint(equalTo: topAnchor),
            detailView.bottomAnchor.constraint(equalTo: bottomAnchor),
            detailView.trailingAnchor.constraint(equalTo: trailingAnchor),
            detailView.heightAnchor.constraint(equalToConstant: 170),
        ])
    }

}
