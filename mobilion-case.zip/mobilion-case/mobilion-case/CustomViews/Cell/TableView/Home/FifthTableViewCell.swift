//
//  FifthTableViewCell.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/11/22.
//

import UIKit

class FifthTableViewCell: UITableViewCell {

    
    private lazy var testImageView : UIImageView = {
       let testImage = UIImageView()
        testImage.sizeToFit()
        testImage.translatesAutoresizingMaskIntoConstraints = false
        testImage.image = UIImage(systemName: "folder")
        
        return testImage
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: Constants.secondCellID)
        setupCell()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupCell() {
        addSubview(testImageView)
        
        NSLayoutConstraint.activate([
        
            testImageView.centerYAnchor.constraint(equalTo: centerYAnchor),
            testImageView.leadingAnchor.constraint(equalTo: leadingAnchor ),
            testImageView.widthAnchor.constraint(equalToConstant: 30),
            testImageView.heightAnchor.constraint(equalToConstant: 30)
        ])
    }

}
