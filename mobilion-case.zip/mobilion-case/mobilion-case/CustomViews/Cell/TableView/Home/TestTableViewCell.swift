//
//  TestTableViewCell.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/11/22.
//

import UIKit

class TestTableViewCell: UITableViewCell {
    
    private lazy var cityCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.sizeToFit()
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        return collectionView
    }()
    private var selectedArray : [CityModel] = []

    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: Constants.testCellID)
        addCollection()
        
        for test in 0..<20 {
            selectedArray.append(CityModel(coord: Coordinate(lat: 20.0, lon: 20.0), country: "TR", id: 32987, name: "Test", state: ""))
        }
        
        cityCollectionView.reloadData()
        
        print(selectedArray.count)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}

// MARK: - UI
extension TestTableViewCell {
    private func addCollection() {
        contentView.addSubview(cityCollectionView)
        
        cityCollectionView.snp.makeConstraints { make in
            make.leading.equalToSuperview()
            make.top.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.greaterThanOrEqualTo(50)
            make.trailing.equalToSuperview()
        }
        cityCollectionView.register(TestCollectionViewCell.self, forCellWithReuseIdentifier: TestCollectionViewCell.Id)
    }
}

// MARK: - UICollectionViewDelegate
extension TestTableViewCell : UICollectionViewDelegate {
    
}

// MARK: - UICollectionViewDataSource
extension TestTableViewCell : UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return selectedArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TestCollectionViewCell.Id, for: indexPath) as! TestCollectionViewCell
        let city = selectedArray[indexPath.row]
        cell.set(data: city)
        return cell
    }
    
}

extension TestTableViewCell: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 100, height: collectionView.frame.height)
    }
}
