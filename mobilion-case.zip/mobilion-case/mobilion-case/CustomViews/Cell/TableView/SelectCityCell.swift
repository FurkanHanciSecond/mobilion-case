//
//  SelectCityCell.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/6/22.
//

import UIKit

class SelectCityCell: UITableViewCell {
    
    private lazy var cityNameLabel = WeatherLabel(fontSize: 14, fontWeight: .medium, textColor: .black)
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        accessoryType = selected ? UITableViewCell.AccessoryType.checkmark : UITableViewCell.AccessoryType.none
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: Constants.selectCityCellID)
        setupCell()
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupCell() {
        selectionStyle = .none
        backgroundColor = .clear
        setupUI()
        
    }
    
    private func setupUI() {
        let padding : CGFloat = 15
        let horizontalPadding: CGFloat = 10
        let verticalPadding: CGFloat = 3
        
        addSubview(cityNameLabel)
        
        cityNameLabel.snp.makeConstraints { make in
            make.leading.equalTo(contentView).offset(padding)
            make.top.equalTo(contentView).offset(padding)
        }
    }
    
    public func setCell(cityData : CityModel) {
        cityNameLabel.text = cityData.name
    }
}
