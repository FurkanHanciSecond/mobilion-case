//
//  WeatherDetailView.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/12/22.
//

import UIKit

class WeatherDetailView: UIView {
    
    
    private lazy var weatherIcon : UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFit
        image.image = UIImage(named: "group579")
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var weatherUpIcon : UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFill
        image.image = UIImage(named: "path5144")
        image.translatesAutoresizingMaskIntoConstraints = false
        
        return image
    }()
    
    private lazy var weatherDownIcon : UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFill
        image.image = UIImage(named: "path5543")
        image.translatesAutoresizingMaskIntoConstraints = false
        
        return image
    }()
    
    private lazy var divider = UIView()
    private lazy var weatherCelcius = WeatherLabel(fontSize: 40, fontWeight: .regular, textColor: Constants.Style.Color.purple ?? .blue)
    private lazy var weatherStatus = WeatherLabel(fontSize: 8, fontWeight: .medium, textColor: Constants.Style.Color.slate ?? .black)
    private lazy var weatherDate = WeatherLabel(fontSize: 12, fontWeight: .bold, textColor: Constants.Style.Color.purple ?? .blue)
    private lazy var weatherMaxCelcius = WeatherLabel(fontSize: 16, fontWeight: .regular, textColor: Constants.Style.Color.slate ?? .black)
    private lazy var weatherMinCelcius = WeatherLabel(fontSize: 16, fontWeight: .regular, textColor: Constants.Style.Color.slate ?? .black)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setup() {
        setupUI()
        setDetail()
        setupTexts()
    }
    
    private func setupTexts() {
        weatherCelcius.text = "35°C"
        weatherCelcius.textColor = Constants.Style.Color.purple
        weatherStatus.text = "Açık, güneşli"
        weatherStatus.textColor = Constants.Style.Color.slate
        weatherDate.text = "7/27/2020"
        weatherDate.textColor = Constants.Style.Color.purple
    }
    
    
    private func setDetail() {
        backgroundColor = Constants.Style.Color.cellBackground
        layer.cornerRadius = 15
        dropShadow()
    }
    
    private func setupUI() {
        let padding : CGFloat = 25
        addSubviews(weatherIcon , weatherUpIcon , weatherDownIcon , divider , weatherCelcius , weatherStatus , weatherDate , weatherMaxCelcius , weatherMinCelcius)
        divider.translatesAutoresizingMaskIntoConstraints = false
        divider.backgroundColor = UIColor(named: "VeryWhite")
        
        
        NSLayoutConstraint.activate([
            
            weatherIcon.centerYAnchor.constraint(equalTo: centerYAnchor),
            weatherIcon.leadingAnchor.constraint(equalTo: leadingAnchor, constant: padding),
            weatherIcon.topAnchor.constraint(equalTo: topAnchor, constant: padding),
            
            weatherCelcius.leadingAnchor.constraint(equalTo: weatherIcon.trailingAnchor, constant: padding),
            weatherCelcius.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            weatherStatus.topAnchor.constraint(equalTo: weatherCelcius.bottomAnchor),
            weatherStatus.leadingAnchor.constraint(equalTo: weatherCelcius.leadingAnchor),
            
            weatherDate.topAnchor.constraint(equalTo: weatherStatus.bottomAnchor),
            weatherDate.leadingAnchor.constraint(equalTo: weatherStatus.leadingAnchor),
            
            divider.leadingAnchor.constraint(equalTo: weatherStatus.trailingAnchor, constant: padding),
            divider.heightAnchor.constraint(equalToConstant: 100),
            divider.centerXAnchor.constraint(equalTo: weatherCelcius.centerXAnchor),
            divider.topAnchor.constraint(equalTo: weatherCelcius.topAnchor),
            divider.widthAnchor.constraint(equalToConstant: 1)

            
        ])
    }
    
}
