//
//  CityViewController.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/5/22.
//

import UIKit

class CityViewController: UIViewController {
    
    private lazy var cityTableView : UITableView = {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.dragDelegate = self
        tableView.dragInteractionEnabled = true
        return tableView
    }()
    

    private var cityData : [CityData]?
    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setup()
        refreshTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchCityData()
    }
    
    private func setup() {
        setupView()
        setNavigationBar()
        setupTableView()
    }
    
    private func setNavigationBar() {
        let addButton = UIBarButtonItem(image: UIImage(named: "group504"), style: .plain, target: self, action: #selector(addCityButton(_:)))
         navigationItem.rightBarButtonItem = addButton
        let editButton = UIBarButtonItem(title: "Düzenle", style: .plain, target: self, action: #selector(editButton(_:)))
        navigationItem.leftBarButtonItem = editButton
    }
    
    @objc private func editButton(_ sender: UIBarButtonItem) {
        if self.cityTableView.isEditing == true
        {
            self.cityTableView.isEditing = false
            self.navigationItem.leftBarButtonItem?.title = "Düzenle"
        }
        else
        {
            self.cityTableView.isEditing = true
            self.navigationItem.leftBarButtonItem?.title = "Bitti"
        }
    }
    
    @objc private func addCityButton(_ sender: UIBarButtonItem) {
        navigationController?.pushViewController(AddCityVC(), animated: true)
    }
    
    private func setupView() {
        view.backgroundColor = UIColor(named: "LightPink")
        title = Constants.Texts.Bar.cities
    }
    
    @objc private func refreshData(_ sender: UIRefreshControl) {
        self.cityTableView.refreshControl?.beginRefreshing()
        self.cityTableView.refreshControl?.endRefreshing()
        self.cityTableView.reloadData()
        self.fetchCityData()
    }
    
    private func fetchCityData() {
        do {
            self.cityData = try context.fetch(CityData.fetchRequest())
            DispatchQueue.main.async {
                self.cityTableView.reloadData()
            }
        } catch  {
            AlertManager.showAlert(message: "Error when fetching datas", viewController: self)
        }
    }
    
    private func refreshTableView() {
        self.cityTableView.refreshControl = UIRefreshControl()
        
        if let refreshControl = cityTableView.refreshControl {
            refreshControl.tintColor = .gray
            refreshControl.addTarget(self, action: #selector(refreshData(_:)), for: .valueChanged)
        }
    }
}

// MARK: - UI

extension CityViewController {
    private func setupTableView() {
        view.addSubview(cityTableView)
        cityTableView.snp.makeConstraints { make in
            make.edges.equalTo(view)
        }
        
        cityTableView.separatorStyle = .none
        cityTableView.backgroundColor = .clear
        cityTableView.backgroundView = .none
        cityTableView.rowHeight = UITableView.automaticDimension
        cityTableView.register(CityCell.self, forCellReuseIdentifier: Constants.cityCellID)
        
    }
}

// MARK: - TableViewDelegate
extension CityViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let action = UIContextualAction(style: .destructive, title: "Sil") { action, view, handler in
            let cityRemove = self.cityData?[indexPath.row]
            self.context.delete(cityRemove ?? cityRemove.unsafelyUnwrapped)
            
            do {
                try self.context.save()
            } catch  {
                AlertManager.showAlert(message: "Silinemedi", viewController: self)
            }
            self.fetchCityData()
        }
        
        return UISwipeActionsConfiguration(actions: [action])
    }
    
}


// MARK: - TableViewDragDelegate

extension CityViewController : UITableViewDragDelegate {
    
    func tableView(_ tableView: UITableView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        let dragItem = UIDragItem(itemProvider: NSItemProvider())
        dragItem.localObject = self.cityData?[indexPath.row]
        return [ dragItem ]
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
        cityData?.swapAt(sourceIndexPath.row, destinationIndexPath.row)
        tableView.moveRow(at: sourceIndexPath, to: destinationIndexPath)
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
}


// MARK: - UITableViewDataSource
extension CityViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cityData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = cityTableView.dequeueReusableCell(withIdentifier: Constants.cityCellID, for: indexPath) as! CityCell
         let cities = self.cityData?[indexPath.row]
        
        cell.setCell(cityData: cities!)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
}

