//
//  SelectCityVC.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/6/22.
//

import UIKit
class SelectCityVC: UIViewController {
    
    private lazy var button = WeatherButton()
    
    private lazy var selectCityTableView : UITableView = {
        let table = UITableView()
        table.delegate = self
        table.dataSource = self
        table.allowsMultipleSelection = true
        return table
    }()
    
    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    private var selectedArray : [CityModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        navigationController?.navigationBar.topItem?.backButtonTitle = ""
    }
    
    private func setup() {
        setupView()
        setupTableView()
        configureButton()
        configureButton()
    }
    
    
    
    private func setupView() {
        view.backgroundColor = .white
    }
    
    private func configureButton() {
        view.addSubview(button)
           button.snp.makeConstraints { make in
               make.leading.equalTo(view)
               make.trailing.equalTo(view)
               make.bottom.equalTo(selectCityTableView).offset(-20)
        }
        
        button.layer.cornerRadius = 20
        button.set(backgroundColor: .cyan, title: "Devam Et")
        button.addTarget(self, action: #selector(handleButton(_:)), for: .touchUpInside)
    }
    
    @objc private func handleButton(_ sender: UIButton) {
        let selectedCity = SelectedCity(context: self.context)
        selectedCity.name = selectedArray.first?.name
        selectedCity.lat = selectedArray.first?.coord?.lat ?? 0
        selectedCity.lon = selectedArray.first?.coord?.lon ?? 0
        let vc = MTabbarController()
        vc.modalPresentationStyle = .fullScreen
        
        if selectedArray.count >= 3 {
            do {
                try self.context.save()
            } catch  {
                AlertManager.showAlert(message: "Error when saving data", viewController: self)
            }
            present(vc, animated: true, completion: nil)
        } else {
            AlertManager.showAlert(message: "En Az 3 Tane İl Seçmelisiniz", viewController: self)
        }
        
    }
}

// MARK: - UI

extension SelectCityVC {
    private func setupTableView() {
        view.addSubview(selectCityTableView)
        selectCityTableView.backgroundColor = .clear
        selectCityTableView.snp.makeConstraints { make in
            make.edges.equalTo(view)
        }
        
        selectCityTableView.rowHeight = UITableView.automaticDimension
        selectCityTableView.register(SelectCityCell.self, forCellReuseIdentifier: Constants.selectCityCellID)
        
    }
}

// MARK: - TableViewDelegate
extension SelectCityVC : UITableViewDelegate {
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return cityArray[section].category
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = selectCityTableView.dequeueReusableCell(withIdentifier: Constants.selectCityCellID, for: indexPath) as! SelectCityCell
        let selectedCity = cityArray[indexPath.section].cityArray[indexPath.row]
        
        selectedArray.append(selectedCity)
        
        print(selectedCity)
        
        cell.isSelected = true
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let deselectedCity = cityArray[indexPath.section].cityArray[indexPath.row]
        
        selectedArray.removeAll {
            $0.name == deselectedCity.name
        }
        
        print(selectedArray.count)
    }
}

// MARK: - TableViewDataSource

extension SelectCityVC: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cityArray[section].cityArray.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
           return cityArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = selectCityTableView.dequeueReusableCell(withIdentifier: Constants.selectCityCellID, for: indexPath) as! SelectCityCell
         let city = cityArray[indexPath.section].cityArray[indexPath.row]
        
        cell.setCell(cityData: city)

        return cell
    }
    
    
}
