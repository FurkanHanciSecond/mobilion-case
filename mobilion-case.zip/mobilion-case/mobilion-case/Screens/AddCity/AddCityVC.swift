//
//  AddCityVC.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/6/22.
//

import UIKit
import CoreData
class AddCityVC: UIViewController , AddCityCellDelegate {
    
    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    private lazy var addCityTableView : UITableView = {
        let table = UITableView()
        table.delegate = self
        table.dataSource = self
        return table
    }()
    
    private lazy var searchBar : UISearchBar = {
        let searchBar = UISearchBar()
        searchBar.searchBarStyle = UISearchBar.Style.default
        searchBar.placeholder = " Search..."
        searchBar.sizeToFit()
        searchBar.isTranslucent = false
        searchBar.backgroundImage = UIImage()
        searchBar.delegate = self
        navigationItem.titleView = searchBar
        
        return searchBar
    }()
    
    private var filteredCities : [City]!
    //  private var cityModel : [CityModel]!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        filteredCities = cityArray
        setup()
        navigationController?.navigationBar.topItem?.backButtonTitle = ""
    }
    
    private func setup() {
        setupView()
        setupTableView()
        configureSearchBar()
    }
    
    func saveData() {
        print("delegate")
    }
    
    
    private func setupView() {
        view.backgroundColor = .white
    }
    
    private func configureSearchBar() {
        view.addSubview(searchBar)
        searchBar.setImage(UIImage(named: "group76"), for: .search, state: .normal)
    }
    
}

// MARK: - UI

extension AddCityVC {
    private func setupTableView() {
        view.addSubview(addCityTableView)
        addCityTableView.backgroundColor = .clear
        addCityTableView.snp.makeConstraints { make in
            make.edges.equalTo(view)
        }
        addCityTableView.rowHeight = UITableView.automaticDimension
        addCityTableView.register(AddCityCell.self, forCellReuseIdentifier: Constants.cellID)
        
    }
}

// MARK: - TableViewDelegate
extension AddCityVC : UITableViewDelegate {
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return filteredCities[section].category
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedCity = cityArray[indexPath.section].cityArray[indexPath.row]
        let cityData = CityData(context: context)
       
        
        NetworkExecuter.shared.execute(route: WeatherAPI.forecast(lat: "\(selectedCity.coord?.lat ?? 45.0)" , long: "\(selectedCity.coord?.lon ?? 40.0)"), responseModel: ForeCast.self) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let dataModel):
                print("data \(dataModel)")
                cityData.latitude = dataModel.city?.coord?.lat ?? 0
                cityData.longitude = dataModel.city?.coord?.lon ?? 0
                cityData.name = dataModel.city?.name
                cityData.date = dataModel.list?.first?.dtTxt ?? ""
                cityData.celcius = "\(dataModel.list?.first?.main?.temp ?? 0)"
                do {
                    try self.context.save()
                    AlertManager.showAlert(title: "Başarılı", message: "Başarılı bir şekilde kaydoldu", alertAction: nil, viewController: self)
                } catch  {
                    AlertManager.showAlert(message: "Kaydedilemedi", viewController: self)
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
        
    }
}

// MARK: - TableViewDataSource

extension AddCityVC: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredCities[section].cityArray.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return filteredCities.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = addCityTableView.dequeueReusableCell(withIdentifier: Constants.cellID, for: indexPath) as! AddCityCell
        let city = filteredCities[indexPath.section].cityArray[indexPath.row]
        cell.delegate = self
        
        cell.setCell(cityData: city)
        return cell
    }
    
    
}

// MARK: - UISearchControllerDelegate

extension AddCityVC : UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredSearch(searchText)
    }
    
    
    func filteredSearch(_ searchText: String) {
        filteredCities = cityArray.filter({
            $0.cityArray.contains {
                return  $0.name?.range(of: searchText , options: .caseInsensitive , range: nil , locale: nil) != nil
            }
        })
        addCityTableView.reloadData()
    }
}
