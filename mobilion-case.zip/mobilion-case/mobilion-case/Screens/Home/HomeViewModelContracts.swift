//
//  HomeViewModelContracts.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/5/22.
//

import Foundation
import UIKit


protocol HomeViewModelContracts {
    var delegate: HomeViewModelDelegate? { get set }
    var numberOfItems: Int { get } 
    
    func getWeather()
    func cellForItemAt(indexPath: IndexPath) -> UITableViewCell
}
protocol HomeViewModelDelegate: AnyObject {
    func reloadData()
}


