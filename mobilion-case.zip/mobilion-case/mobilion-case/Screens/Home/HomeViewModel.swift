//
//  HomeViewModel.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/5/22.
//

import Foundation
import UIKit

final class HomeViewModel : HomeViewModelContracts {
    
    weak var delegate: HomeViewModelDelegate?
    private var foreCast: ForeCast?
    
    var numberOfItems: Int {
        return foreCast?.list?.count ?? 0
    }
    
    func cellForItemAt(indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell()
    }
}

// MARK: -  Requests
extension HomeViewModel {
    
    func getWeather() {
        NetworkExecuter.shared.execute(route: WeatherAPI.forecast(lat: "37.75", long: "38.25"), responseModel: ForeCast.self) { [weak self]  result in
            guard let self = self else { return }
            switch result {
            case .success(let model):
                print(model)
                self.foreCast = model
                self.delegate?.reloadData()
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}
