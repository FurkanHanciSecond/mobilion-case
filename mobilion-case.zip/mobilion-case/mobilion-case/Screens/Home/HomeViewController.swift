//
//  HomeViewController.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/4/22.
//

import UIKit
import SnapKit

final class HomeViewController: UIViewController {
    
    var viewModel: HomeViewModelContracts = HomeViewModel()
    private var selectedCityArray : [SelectedCity] = []
    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    private lazy var homeTableView: UITableView = {
        let table = UITableView()
        table.delegate = self
        table.dataSource = self
        return table
    }()
    
    private var sectionArray : [String] =  ["Hava Durumu" , "Hava Durumu" , "Hava Durumu" , "Günlük Detay" , "Haftalık Hava Durumu"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addSubViews()
        view.backgroundColor = UIColor(named: "LightPink")
        title = Constants.Texts.Bar.home
        viewModel.delegate = self
        viewModel.getWeather()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchSelectedCities()
    }
    
    private func fetchSelectedCities() {
        do {
            self.selectedCityArray = try context.fetch(SelectedCity.fetchRequest())
            DispatchQueue.main.async {
                self.viewModel.delegate?.reloadData()
            }
        } catch  {
            AlertManager.showAlert(message: "Fetch", viewController: self)
        }
    }
}

// MARK: -  UI Layout
extension HomeViewController {
    
    private func addSubViews() {
        addCollectionView()
    }
    
    private func addCollectionView() {
        view.addSubview(homeTableView)
        homeTableView.snp.makeConstraints { make in
            make.edges.equalTo(view)
        }
        homeTableView.separatorStyle = .none
        homeTableView.register(TestTableViewCell.self, forCellReuseIdentifier: Constants.testCellID)
        homeTableView.register(SecondTableViewCell.self, forCellReuseIdentifier: Constants.secondCellID)
        homeTableView.register(ThirdTableViewCell.self, forCellReuseIdentifier: Constants.thirdCellID)
        homeTableView.register(FourthTableViewCell.self, forCellReuseIdentifier: Constants.fourthCellID)
        homeTableView.register(FifthTableViewCell.self, forCellReuseIdentifier: Constants.fifthCellID)



    }
    
}

// MARK: - Outputs
extension HomeViewController: HomeViewModelDelegate {
    
    func reloadData() {
        homeTableView.reloadData()
    }
}

// MARK: - UITableViewDelegate

extension HomeViewController : UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: homeTableView.frame.width, height: 40))
        headerView.backgroundColor = .clear
        let label = UILabel(frame: CGRect(x: 15, y: 0, width: view.frame.width - 15, height: 40))
        headerView.addSubview(label)
       
        label.text = sectionArray[section]
        label.backgroundColor = .clear
        label.textColor = Constants.Style.Color.slate
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
}


// MARK: - UITableViewDataSource

extension HomeViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
           return 1
            
        case 1:
            return 1
            
        case 2:
            return 1
            
        case 3:
            return 1
            
        case 4:
            return 1
            
        default:
            return 5
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            let cell = homeTableView.dequeueReusableCell(withIdentifier: Constants.testCellID, for: indexPath) as! TestTableViewCell
            cell.backgroundColor = .red
            return cell
        } else if indexPath.section == 1 {
            let cell = homeTableView.dequeueReusableCell(withIdentifier: Constants.secondCellID, for: indexPath) as! SecondTableViewCell
            return cell
        } else if indexPath.section == 2{
            let cell = homeTableView.dequeueReusableCell(withIdentifier: Constants.thirdCellID, for: indexPath) as! ThirdTableViewCell
            cell.backgroundColor = .green
            return cell
        } else if indexPath.section == 3 {
            let cell = homeTableView.dequeueReusableCell(withIdentifier: Constants.fourthCellID, for: indexPath) as! FourthTableViewCell
            cell.backgroundColor = .yellow
            return cell
        } else if indexPath.section == 4 {
            let cell = homeTableView.dequeueReusableCell(withIdentifier: Constants.fifthCellID, for: indexPath) as! FifthTableViewCell
            cell.backgroundColor = .blue
            return cell
        }
        
      return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    
    
}
