//
//  WeatherAPI.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/5/22.
//

import Foundation

enum WeatherAPI : BaseClientGenerator {
    
    case forecast(lat: String, long: String)
        
    var scheme: String { "https" }
    
    var host: String { "api.openweathermap.org" }
    
    var path: String {
        switch self {
        case .forecast(_, _):
            return "/data/2.5/forecast"
        }
    }
    
    var queryItems: [URLQueryItem]?{
        var query: [URLQueryItem] = []
        switch self {
        case .forecast(let lat, let long):
            query.append(.init(name: "lat", value: lat))
            query.append(.init(name: "lon", value: long))
        }
        
        query.append(.init(name: "units", value: "imperial"))
        query.append(.init(name: "appid", value: "52e6ff60bba8613b4850e065dcd3d0ac"))
        return query
    }
    
    //MARK: - Default GET
    var method: HttpMethod {
        switch self {
        default:
            return .get
        }
    }
    
    var header: [HttpHeader]? {
        return [
            .contentType(),
            .bearerToken(token: Constants.apiKey)
        ]
    }
    
    //MARK: - Default Nil
    var body: [String : Any]? {
        switch self {
        default:
            return nil
        }
    }
}
