//
//  NetworkError.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/5/22.
//

import Foundation

enum NetworkError : Error, LocalizedError {
    case invalidURL
    case request(statusCode : Int,data : Data?)
    case badRequest
    case decodeError
    case noInternet
    case noResponse
    case responseConvert
    case noData
}
