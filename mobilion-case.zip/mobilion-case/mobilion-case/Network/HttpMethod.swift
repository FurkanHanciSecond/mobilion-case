//
//  HttpMethod.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/5/22.
//

import Foundation

enum HttpMethod : String {
    case get = "GET"
    case post = "POST"
    case delete = "DELETE"
    case put = "PUT"
}
