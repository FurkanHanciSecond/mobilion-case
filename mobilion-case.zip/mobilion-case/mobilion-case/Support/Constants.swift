//
//  Constants.swift
//  mobilion-case
//
//  Created by Furkan Hanci on 3/5/22.
//

import UIKit

struct Constants {
    static let baseURL = "api.openweathermap.org"
    static let apiKey = "52e6ff60bba8613b4850e065dcd3d0ac"
    static let cellID = "addCityCell"
    static let cityCellID = "cityCell"
    static let selectCityCellID = "selectCityCell"
    
    
    static let testCellID = "testCell"
    static let secondCellID = "secondCell"
    static let thirdCellID = "thirdCell"
    static let fourthCellID = "fourthCell"
    static let fifthCellID = "fifthCell"
    
    struct Texts {
        enum Bar {
            static let home = "Ana Sayfa"
            static let cities = "Şehirler"
        }
        
        enum Error {
            static let oops = "Hata"
            static let ok = "Tamam"
        }
    }
    
    struct Style {
        enum Color {
            static let lightGray = UIColor.lightGray
            static let cellShadow = UIColor(named: "BlueGray")
            static let tabBarTintColor = UIColor(named: "White")
            static let tabTintColor = UIColor(named: "Purple")
            static let navBarTintColor = UIColor.white
            static let purple = UIColor(named: "Purple")
            static let slate = UIColor(named: "Slate")
            static let navTintColor = UIColor(named: "Purple")
            static let navTextColor = UIColor(named: "Slate")
            static let label = UIColor.label
            static let black = UIColor.black
            static let cellBackground = UIColor(named: "White")
        }
        
        enum Image {
            static let homeTabImage = UIImage(named: "group40")
            static let cityTabImage = UIImage(named: "path5542")
        }
    }
}
